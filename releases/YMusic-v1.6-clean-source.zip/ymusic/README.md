# YMusic v1.6 — Clean Source

هذا أرشيف السورس النظيف للمشروع بدون node_modules أو APK أو ملفات Android المبنية.

## تشغيل الواجهة والـAPI

```bash
npm install
npm run check
npm test
npm run build
npm start
```

## تجهيز Android وبناء APK

```bash
cd android_build
npm install
npm run setup
npm run build:debug
```

سيتم إنشاء مشروع Android وملفات البناء تلقائيًا عند تشغيل `setup`.
